Ausgewählte Bedingung für Schein:
Prozedurale Levelgenerierung im Spiel
Es gibt verschiedene Szenen, die zufällig aneinander gehängt werden, sodass jeder Versuch auf einer "neuen" bzw anderen Map stattfindet.
Ähnlich zu Handyspielen wie Subway-Surfer oder Drifto

MfG
Tristan Hofmann, Linus Lange, Felix Hillmann